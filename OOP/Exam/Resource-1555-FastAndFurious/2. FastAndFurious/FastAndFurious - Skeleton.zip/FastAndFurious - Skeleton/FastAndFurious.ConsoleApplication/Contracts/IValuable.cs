﻿namespace FastAndFurious.ConsoleApplication.Contracts
{
    public interface IValuable
    {
        decimal Price { get; }
    }
}
